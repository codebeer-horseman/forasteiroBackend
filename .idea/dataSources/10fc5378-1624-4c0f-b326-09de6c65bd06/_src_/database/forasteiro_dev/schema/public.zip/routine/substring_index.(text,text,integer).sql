CREATE FUNCTION substring_index (text, text, integer) RETURNS text
	LANGUAGE sql
AS $$
SELECT array_to_string((string_to_array($1, $2)) [1:$3], $2);
$$
