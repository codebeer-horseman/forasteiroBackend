CREATE FUNCTION rand () RETURNS double precision
	LANGUAGE sql
AS $$
SELECT random();
$$
